package com.fis.bankApplicationMicroservices.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankApplicationMicroservices.exception.UserNotFound;
import com.fis.bankApplicationMicroservices.model.Logger;
import com.fis.bankApplicationMicroservices.repository.LoggerRepo;

@Service
public class LoggerService {
	@Autowired
	LoggerRepo loggerRepo;
// method is used to add a log to the database
	public void addLog(Logger logger) {
		loggerRepo.save(logger);
	}
// method is used to retrieve a log by its account ID
	public Logger showLog(int acctID) throws UserNotFound {
		Optional<Logger> optional = loggerRepo.findById(acctID);
		if (optional.isPresent()) {
			return optional.get();
		} else {
			throw new UserNotFound("Account Number is invalid...");
		}
		//return loggerRepo.findById(acctID).orElse(null);
	}
// method is used to delete a log by its account ID
	public void deleteLog(int acctID) {
		loggerRepo.deleteById(acctID);
	}
}
