package com.fis.bankApplicationMicroservices.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
public class BankCustomer {

	@Id
	private int acctID;
	@NotBlank(message = "Customer name cannot be null or whitespace")
	private String custName;
	private String city;
	private String state;
	private String country;
	private long phoneNo;
	@NotBlank(message = "password cannot be null or whitespace")
	private String password;

	public BankCustomer() {

	}

	public BankCustomer(int acctID, String custName, String city, String state, String country, long phoneNo,
			String password) {
		super();
		// initialize account ID , customer name, city, state, country, phoneno, password
		this.acctID = acctID;
		this.custName = custName;
		this.city = city;
		this.state = state;
		this.country = country;
		this.phoneNo = phoneNo;
		this.password = password;
	}
// add getters and setters to this
	public int getAcctID() {
		return acctID;
	}

	public int setAcctID(int acctID) {
		return this.acctID = acctID;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCity() {
		return city;
	}

	public String setCity(String city) {
		return this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public long setPhoneNo(long phoneNo) {
		return this.phoneNo = phoneNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

}
